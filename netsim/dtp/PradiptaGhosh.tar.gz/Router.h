class FIFONode;

class Router : public FIFONode 
{
 public:
    Router(Address a, int b);
    ~Router();
};
